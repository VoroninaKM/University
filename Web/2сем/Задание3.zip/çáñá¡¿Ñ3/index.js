const express = require('express');
const axios = require('axios');

const port = 3001;
const app = express();
const server = require('http').createServer(app);

app.get('/', (req, res) =>{
    let response = null;
    new Promise(async  (resolve, reject) => {
        try{
            response = await axios('https://www.cbr-xml-daily.ru/daily_json.js');
        } catch (er) {
            response = null;
            console.log(er);
            reject(er);
        }
        if(response){
            const json = response.data;
            var course = json['Valute']['USD']['Value'];
            console.log(course);
            resolve(json);
            res.send(`${json.Valute["USD"]["Value"]}`);
        }
    })
})
server.listen(port, function () {
    console.log('Слушаем порт');
})
